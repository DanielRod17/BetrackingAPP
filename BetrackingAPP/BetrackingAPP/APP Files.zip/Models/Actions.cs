﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BetrackingAPP.Models
{
    public class Actions
    {
        public string ActionName { get; set; }
        public string ActionDate { get; set; }
    }
}
