﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BetrackingAPP.Models
{
    public class Notification
    {
        public string Title { get; set; }
        public string Message { get; set; }
        public string cName { get; set; }
    }
}
