﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BetrackingAPP.Models
{
    public class NewTimecardNormal
    {
        public string Day { get; set; }
        public int Numero { get; set; }
        public decimal Valor { get; set; }
        public string Nota { get; set; }
        public int DisplayInputs { get; set; }

    }
}
