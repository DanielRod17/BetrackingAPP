﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace BetrackingAPP.Models
{
    public class Constants
    {
        public static bool IsDev = true;

        public static Color BackgroundColor = Color.FromRgb(244, 244, 244);
        


        public static int LoginIconHeight = 80;
    }
}
